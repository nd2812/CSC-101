#include <stdio.h>

int main() {
    int a[10], b,c=0,d=0,e=0,f=0;
      printf("Enter the 10 value:");
    for(int i=0; i<10;i++){
    scanf("%d", &a[i]);
    }
 
    for(int j=0; j<10;j++){
        if(a[j]%2==0){
            c++;
        }
        if(a[j]%2!=0){
            d++;
        }
        if(a[j]>0){
            e++;
        }
         if(a[j]<0){
            f++;
        }
    }
     printf("\n%d counts of even number.\n",c);
     printf("%d counts of odd number.\n",d);
     printf("%d counts of postive number.\n",e);
     printf("%d counts of negative number.\n",f);

    return 0;
}