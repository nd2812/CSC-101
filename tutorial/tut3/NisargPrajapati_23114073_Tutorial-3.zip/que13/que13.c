#include<stdio.h>
int main(){
    int n;
    printf("Enter the size of the array:");
    scanf("%d",&n);
    int a[n];
    printf("Enter the elements in the array:\n");
    for(int i=0;i<n;i++)
    scanf("%d",&a[i]);
    for(int i=0;i<n;i++){
        int m=a[i],c=0;
        for(int j=0;j<n;j++){
            if(a[j]==m)
            c++;
        }
        if(c>n/2){
            printf("The majority element in the array is %d \n",m);
            return 0;
        }
    }
    printf("No majority element exists");
    return 0;
}