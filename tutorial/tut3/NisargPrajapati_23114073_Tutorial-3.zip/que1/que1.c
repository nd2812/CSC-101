#include <stdio.h>

int main() {
    int n;
    printf("Enter the size of array:");
    scanf("%d",&n);
    int a[n],b,c=0;
      printf("Enter the %d values:",n);
    for(int i=0; i<n;i++){
    scanf("%d", &a[i]);
    }
    printf("Search for the number :");
    scanf("%d",&b);
    for(int j=0; j<n;j++){
        if(b==a[j]){
            c++;
        }
    }
    printf("The number %d is present %d times in the array.\n",b,c);
    
    return 0;
}