#include<stdio.h>
int main(){
    int n,b=1;
    printf("Enter the number of intervals:");
    scanf("%d",&n);
    int a[n][2],c[n];
    printf("Enter the intervals [a,b] by giving values of a and b:\n");
    for(int i=0;i<n;i++){
        scanf("%d",&a[i][0]);
        scanf("%d",&a[i][1]);
        if(a[i][0]>a[i][1]){
            printf("Invalid Input");
            return 0;
        }
        c[i]=0;
    }
    while(b>0){
        b=0;
    for(int i=0;i<n;i++){
        if(c[i]==0)
        for(int j=0;j<n;j++){
            if(c[j]==0 && i!=j){
                if(a[j][0]>a[i][0]&&a[i][1]>=a[j][0]&&a[i][1]<=a[j][1]){
                    c[j]=1;
                    a[i][1]=a[j][1];
                    a[j][0]=a[j][1]=0;
                    b=1;
                }
                else if(a[i][0]<a[j][0]&&a[i][1]>a[j][1]){
                    c[j]=1;
                    a[j][0]=a[j][1]=0;
                    b=1;
                }
            }
        }
    }
}
    printf("Intervals after merging are:\n");
    for(int i=0;i<n;i++){
        if(c[i]==0){
            printf("[%d,%d]\t",a[i][0],a[i][1]);
        }
    }
    printf("\n");
    return 0;
}