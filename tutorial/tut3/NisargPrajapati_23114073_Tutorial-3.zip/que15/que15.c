#include<stdio.h>
#include<string.h>

int main(){
    char st[100];
    printf("Enter a string:");
    scanf("%s",st);
    int len=strlen(st);
    char st2[200]="",ch=st[0];
    int c=1,in=0;
    for(int i=1;i<len;i++){
        if(st[i]==ch){
            c++; 
        }
        else{
            sprintf(st2+in,"%c%d",ch,c); 
            ch=st[i];
            in+=2;
            c=1;
        }
    }
    sprintf(st2+in,"%c%d",ch,c); 
    if(strlen(st2)<len){
        printf("Compressed string:%s\n",st2);
    }
    else{
        printf("Original string:%s\n",st);
    }
    return 0;
}