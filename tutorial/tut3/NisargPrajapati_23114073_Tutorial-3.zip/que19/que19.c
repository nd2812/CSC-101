#include<stdio.h>
#include<string.h>

int main(){
    char st[100];
    printf("Enter the string:");
    scanf("%s",st);
    int len=strlen(st);
    int stk[len];
    int ptr=-1;
    for(int i=0;i<len;i++)
    stk[i]=0;
    for(int i=0;i<len;i++){
        if(st[i]=='(' || st[i]=='['){
            stk[++ptr]=st[i];
        }
        else if(st[i]==')' || st[i]==']'){
            if(ptr==-1){
                printf("String is not valid");
                return 0;
            }
            int temp=stk[ptr--];
            if(st[i]-1!=temp && st[i]-2!=temp){
                printf("String is Invalid\n");
                return 0;
            }
        }
        else{
            if(st[i]!=32){
                printf("Invalid input\n");
                return 0;
            }
        }
    }
    if(ptr==-1){
        printf("String is valid\n");
    }
    else{
        printf("String is Invalid\n");
    }
    return 0;
}
