#include <stdio.h>

int main() {
    int arr[10]={2,4,7,3,4,5,9,13,11,12},n=0;
    for(int i=0;i<8;i++){
        if(arr[i]==arr[i+1]-1 && arr[i+1]==arr[i+2]-1){
            n=1;
        }
    }
    if(n==1){
        printf("There are 3 numbers which are consucative in array \n");
    }
    else{
         printf("There are not 3 numbers which are consucative in array\n");
    }
    
    return 0;
}