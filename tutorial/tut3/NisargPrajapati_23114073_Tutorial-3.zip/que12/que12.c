#include<stdio.h>
#include<stdlib.h>
int main(){
    int n;
    printf("Enter the value of n:");
    scanf("%d",&n);
    int a1[n],a2[n];
    printf("Enter the elements in the first array:\n");
    for(int i=0;i<n;i++){
        scanf("%d",&a1[i]);
    }
    printf("Enter the elements in the second array:\n");
    for(int i=0;i<n;i++){
        scanf("%d",&a2[i]);
    }
    int diff=abs(a1[0]-a2[0]);
    int i1=0,i2=0;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(diff>abs(a1[i]-a2[j])) {
                diff=abs(a1[i]-a2[j]);
                i1=i;
                i2=j;
            }
        }
    }
    printf("The smallest difference is %d (between %d from 'arr1' and %d from 'arr2')\n",diff,a1[i1],a2[i2]);
    return 0;
}