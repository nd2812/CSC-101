#include<stdio.h>
#include<string.h>
int main(){
    int f=0;
    char s[100]="";
    int a[256];
    for(int i=0;i<256;i++){
        a[i]=0;
    }
    printf("Enter a string:");
    scanf("%s",s);
    for(int i=0;i<strlen(s);i++){
        a[s[i]]++; 
    }
    for(int i=0;i<256;i++){
        if(a[i]%2!=0)
        f++;
    }
    if(f<2){
        printf("String is permutatuion of the palindrome\n");
    }
    else{
        printf("String is not permutation of the palindrome\n");
    }
    return 0;
}