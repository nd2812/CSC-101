#include<stdio.h>

double det(double a1[5][5],int count){
    if(count>1){
        double sum=0;
        for(int c=0;c<count;c++){
            double b[5][5];int r=0,cl=0;
            for(int i=1;i<count;i++){
                for(int j=0;j<count;j++){
                    if(j!=c)
                    b[r][cl++]=a1[i][j];
                }
                r++;
                cl=0;
            }
            if(c%2==0){
                sum+=a1[0][c]*det(b,count-1);
            }
            else{
                sum-=a1[0][c]*det(b,count-1);
            }
        }
        return sum;
    }
    else
    return (a1[0][0]);
}
int main()
{
    double a[5][5];
    printf("Enter the elements in a 5X5 matrix:\n");
     for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            printf("a[%d][%d] :",i+1,j+1);
            scanf("%lf",&a[i][j]);
        }
    }
    printf("Matrix is:\n");
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            printf("%lf\t",a[i][j]);
        }
        printf("\n");
    }
    printf("Determinant is:%lf\n",det(a,5));
    return 0;
}