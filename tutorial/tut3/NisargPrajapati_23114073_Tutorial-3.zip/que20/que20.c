#include <stdio.h>
#include <string.h>
#include <stdbool.h>

bool areIsomorphic(char *str1, char *str2){
    if (strlen(str1) != strlen(str2)){
        return false;
    }
    int arr1[256] = {0}, arr2[256] = {0};
    for (int i = 0; i < strlen(str1); i++){
        if (arr1[(int)str1[i]] != arr2[(int)str2[i]]){
            return false;
        }
        arr1[(int)str1[i]]++;
        arr2[(int)str2[i]]++;
    }
    return true;
}

int main(){
    char s1[50], s2[50] ;
    printf("Enter the first word:"); 
    scanf("%s",s1);

    printf("Enter the second word:");
    scanf("%s",s2);

    if (areIsomorphic(s1, s2))
        printf("Yes,they are isomorphic \n");
    else
        printf("No,they are not isomorphic\n");

    return 0;
}