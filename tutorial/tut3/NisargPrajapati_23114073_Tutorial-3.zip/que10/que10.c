#include<stdio.h>
int main(){
    int n;
    printf("Enter the number of elements in the array:");
    scanf("%d",&n);
    int a[n];
    printf("Enter the elements in the array:\n");
    for(int i=0;i<n;i++)
    scanf("%d",&a[i]);
    int s=0,m=a[0],d=0,e=0;
    for(int i=0;i<n;i++){
        s=a[i];
        for(int j=i,f=0;j<n&&f==0;j++){
            if(j!=i){
                s+=a[j];
            }
            if(s<0) {   
                f=1; 
            }  
            if(s>m){
                m=s;
                d=i;  
                e=j;
            }
        }
    }
    printf("The contiguous subarray with largest sum is:\n");
    for(int i=d;i<=e;i++){
        printf("%d  ",a[i]); 
    }  
    printf("\nsum:%d\n",m);
    return 0;
}