#include <stdio.h>

int main() {
    int n,k;
    printf("Enter the order of matrix which is even number:");
    scanf("%d",&n);
    int a1[n][n],a2[n][n];
    for(int j=0;j<n;j++){
        for(int i=0;i<n;i++){
            printf("a[%d][%d] =",j+1,i+1);
            scanf("%d",&a1[j][i]);
        }
    }
    printf("Enter the degree that you want to rotate the matrix(90 or 180):");
    scanf("%d",&k);
    if(k==90){
        for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            int t=a1[i][j];
            a1[i][j]=a1[j][i];
            a1[j][i]=t;
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n/2;j++){
            int t=a1[i][j];
            a1[i][j]=a1[i][n-1-j];
            a1[i][n-1-j]=t;
        }
    }
    printf("Matrix after rotation of 90 degree is:\n");
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            printf("%d\t",a1[i][j]);
        }
        printf("\n");
    }
    }
    
    else if(k==180){
        for(int j=0;j<n;j++){
        for(int i=0;i<n;i++){
            a2[j][i]=a1[n-1-j][n-1-i];
            printf("%d ",a2[j][i]);
        }
        printf("\n");
    }
    }
    else{
        printf("enter the valid degree.");
    }
    return 0;
}