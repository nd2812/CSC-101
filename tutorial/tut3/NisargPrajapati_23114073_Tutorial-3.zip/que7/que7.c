#include <stdio.h>

int main() {
    int n;
    printf("Enter the order of matrix which is even number:");
    scanf("%d",&n);
    if(n%2==0){
    int a[n][n];
    for(int j=0;j<n;j++){
        for(int i=0;i<n;i++){
            printf("a[%d][%d] =",j+1,i+1);
            scanf("%d",&a[j][i]);
        }
    }
    for(int j=0;j<n;j+=2){
        for(int i=0;i<n;i+=2){
            printf("%d %d  \n%d %d  \n\n",a[j][i],a[j][i+1],a[j+1][i],a[j+1][i+1]);
            
        }
        
    }
    }
    else{
        printf("Enter the valid order.");
    }

    return 0;
}