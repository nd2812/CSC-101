#include<stdio.h>

int main(){
    int nums[4]={2,7,11,15},target = 9,a=0;
    for(int i=0;i<4;i++){
        for (int j=0;j<4;j++){
            if(nums[i]!=nums[j]){
                if(nums[i]+nums[j]== target){
                    a=1;
                }
            }
        }
    }
    if(a==1){
        printf("True\n");
    }
    else{
        printf("False\n");
    }
    return 0;
}