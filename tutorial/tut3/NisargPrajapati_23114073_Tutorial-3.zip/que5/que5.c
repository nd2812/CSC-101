#include <stdio.h>
#include <string.h>

int main(){
    char a[50], b[50];
    int c = 0;
    printf("Enter the first words:");
    fgets(a, sizeof(a), stdin);
    printf("Enter the second words:");
    fgets(b, sizeof(b), stdin);
    for (int i = 0; i < strlen(a); i++){
        for (int j = 0; j < strlen(b); j++){
            if (a[i] == b[j]){
                c++;
                break;
            }
        }
    }
    if (c == strlen(a)){
        printf("words are anagrams\n");
    }
    else{
        printf("words are not anagrams\n");
    }
    return 0;
}