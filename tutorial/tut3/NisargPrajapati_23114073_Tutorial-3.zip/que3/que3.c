#include <stdio.h>

int main() {
    int n;
    printf("Enter the size of array:");
    scanf("%d",&n);
    double arr1[n],arr2[n];
    for(int i=0;i<n;i++){
        scanf("%lf",&arr1[i]);
    }
    for(int i=0;i<n;i++){
        arr2[i]=arr1[n-1-i];
    }
    for(int i=0;i<n;i++){
        printf("%lf ,",arr2[i]);
    }
    printf("\n");
    return 0;
}