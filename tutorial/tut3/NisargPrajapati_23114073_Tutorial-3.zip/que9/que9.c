#include <stdio.h>
#include <string.h>

int main() {
char st[100];
printf("Enter the sentance:");
fgets(st,sizeof(st),stdin);
int len= strlen(st);
int i=len-1,j,t;
for(t=len-1;t>=0;t--){

    if(st[t]==' '){
        for(j=t+1;j<i;j++){
            printf("%c",st[j]);
        }
        if(st[t]==' '){
        printf(" ");
        }
        i=t;
    }
    
}
for(j=0;j<i;j++){
            printf("%c",st[j]);
        }
    printf("\n");
    return 0;
}