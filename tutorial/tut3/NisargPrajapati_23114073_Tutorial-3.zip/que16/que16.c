#include <stdio.h>  
#include <string.h>  
   
int main()  {  
    char s1[50], s2[50]; 

    printf("Enter the first word:"); 
    scanf("%s",s1);

    printf("Enter the second word:");
    scanf("%s",s2);

          
    if(strlen(s1) != strlen(s2)){  
        printf("Second word is not a rotation of first word\n");  
    }  
    else{   
        strcat(s1, s1);  
        if(strstr(s1, s2) != NULL) { 
            printf("Second word is a rotation of first word\n");  
        }
        else  {
            printf("Second word is not a rotation of first word\n");  
        }
    }  
   
    return 0;  
}  