#include<stdio.h>

int main(){
int x = 2%2+2*2-2/2;
printf("%d ",x);
    return 0;
}