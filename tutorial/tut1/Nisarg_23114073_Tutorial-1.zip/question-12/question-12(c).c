#include<stdio.h>
#include<math.h>
int main(){
    int i=8, j=5;
    float r=0.005, q=-0.01,n,m;
    n=remainder(j*(i-3),r+q-2+i);
    m=5*((i/7)+n);
    printf("%f",m);
    return 0;
}