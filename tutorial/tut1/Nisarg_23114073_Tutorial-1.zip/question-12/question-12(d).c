#include<stdio.h>

int main(){
    int t=6,y;
    y=t*7+2;
    printf("%d",y);
    return 0;
}