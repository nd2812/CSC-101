#include<stdio.h>

int main(){
    int a=4,b=5,c=6,d;
    d=((a < b)||(b > c) || (a > b)||(!(a > c)));
    printf("%d",d);
    return 0;
}