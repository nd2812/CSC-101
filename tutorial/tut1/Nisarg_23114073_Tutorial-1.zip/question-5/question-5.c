#include <stdio.h>
int main()
{
    float a,b,c,d;
    printf("Enter the coeff. of quadratic equation a,b,c:");
    scanf("%f%f%f",&a,&b,&c);
    d=b*b-4*a*c;
    if(d<0){
        printf("roots are complex");
    }
    else if(d>0){
        printf("roots are real&distict");
    }
    else{
        printf("roots are real&equal");
    }
    return 0;
}