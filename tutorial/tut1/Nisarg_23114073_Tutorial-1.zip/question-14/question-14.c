#include <stdio.h>

 int main()
{
   int i, s=0;
   printf("Numbers between 50 and 100, divisible by 7 : \n");
   for(i=51;i<100;i++)
   {
     if(i%7==0)
     {
       printf("% d",i);
       s+=i;
     }
   }
   printf("\nThe sum : %d \n",s);
}
