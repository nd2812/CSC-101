#include <stdio.h>
int main(void){
 
    int a, b, i, m;
    printf("Enter a and b values : ");
    scanf("%d%d",&a,&b);
 
    for(i=1;i<=b;i++)
    {
        m= m + a;
    }
    printf("Multiplication is : %d \n",m);
    return 0;
}