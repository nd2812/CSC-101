#include<stdio.h>
#include<math.h>
int main(){
       int c=2,i;
float b;
 printf("Power of 2:\n");
for(i=1;i<51;i++){
    b=pow(c,i);
    printf("%.0f\n",b);
}
    return 0;
}