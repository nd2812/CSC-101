#include<stdio.h>

int main()
{
    float a, c;
    printf("Give a number in centimeter:");
    scanf("%f", &a);
    int b = a / 12 / 2.54;
    c = (a / 12 / 2.54 - b) * 12;
    printf("%.1f centimeters is %d feet %.1f inches.", a, b, c);
    return 0;
}