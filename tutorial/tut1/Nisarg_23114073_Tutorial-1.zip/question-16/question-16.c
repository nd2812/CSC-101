#include <stdio.h>
int main()
{

    printf(" The common header files in C/C++:\n");
    printf("stdio.h\n");
    printf("math.h\n");
    printf("signal.h\n");
    printf("float.h\n");
    printf("ctype.h\n");
    printf("stdarg.h\n");
    printf("errorno.h\n");
    printf("assert.h\n");
    printf("string.h\n");
    printf("limits.h\n");
    printf("time.h\n");
}