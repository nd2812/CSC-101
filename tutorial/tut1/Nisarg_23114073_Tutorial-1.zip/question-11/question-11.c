#include<stdio.h>

int main(){
    int a,amt;
    printf("Enter the number of units:");
    scanf("%d",&a);
    if(a>0 && a<=200){
        amt=0;
    }
    else if(a>200 && a<=400){
        amt=(a-200)*5;
    }
    else if(a>400 && a<=600){
        amt=1000+(a-400)*7;
    }
else if(a>600 && a<=800){
        amt=2400+(a-600)*9;
    }
else if(a>800){
        amt=4200+(a-800)*11;
    }
printf("Amount of the bill will be %d Rs.",amt);
    return 0;
}