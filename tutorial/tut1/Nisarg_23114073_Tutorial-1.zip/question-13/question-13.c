#include <stdio.h>  
#include <conio.h>  
int main()  
{    
    int x, y, i, g;  
    printf ( " Enter any two numbers: \n ");  
    scanf ( "%d %d", &x, &y);
    for( i = 1; i <= x && i <= y; ++i)  
    {  
        if (x % i ==0 && y % i == 0)  
            g = i;
    }  
    printf (" GCD of two numbers %d and %d is %d.", x, y, g);  
    return 0;  
}  