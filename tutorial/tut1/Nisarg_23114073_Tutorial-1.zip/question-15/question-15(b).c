#include <stdio.h>
int main()
{
    int a,i,f;
    f=i=1;
    printf("Enter a Number : ");
    scanf("%d",&a);
    while(i<=a)
    {
        f*=i;
        i++;
    }
    printf("The Factorial of %d is : %d",a,f);
    return 0;
}
