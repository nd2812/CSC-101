#include <stdio.h>
int main(){
    int a, b, r,q ;
    printf("Enter a three-digit integer: ");
    scanf("%d", &a);
b = a;
    while (b!= 0)
    {
        r =b % 10;
        q += r * r * r;
        b/= 10;
    }
    if (q == a)
        printf("%d is an Armstrong number.", a);
    else
        printf("%d is not an Armstrong number.", a);

    return 0;
}
