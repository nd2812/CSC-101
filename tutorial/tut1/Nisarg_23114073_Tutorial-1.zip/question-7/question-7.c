#include<stdio.h>
int main(){
int n,r;
printf("Enter a 5-digit number:");
scanf("%d",&n);

if(n<10000 || n>99999){
    printf("Please enter a valid 5-digit number");
}
int tenthousands = n/10000;
int thou= (n % 10000)/1000;
int hun=(n % 1000)/100;
int ten=(n %100)/10;
int one=n % 10;
 r = one*10000 + ten * 1000 + hun * 100 + thou * 10 + tenthousands;
 printf("Reversed number: %d\n",r);
    return 0;
}