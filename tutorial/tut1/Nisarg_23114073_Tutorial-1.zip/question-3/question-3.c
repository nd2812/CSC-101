#include <stdio.h>

int main()
{
    int a, b, c, d;
    printf("give a number in seconds:");
    scanf("%d", &a);
    b = a / 3600;
    c = (a - b * 3600) / 60;
    d = (a - b * 3600) % 60;
    printf("%d seconds is equivalent to %d hours %d minutes %d seconds", a, b, c, d);
    return 0;
}