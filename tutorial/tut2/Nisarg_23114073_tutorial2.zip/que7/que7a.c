#include<stdio.h>

int main(){
    int n,i, sumf=1,sumw=1,sumd=1;
    printf("enter a number:");
    scanf("%d", &n);

    // using for loop 
    for(i=1;i<n;i++){
        sumf+=i*5;
    }
    printf("sum using for loop is %d.\n",sumf);
    i=1;

    // using while loop
    while(i<n){
        sumw+=i*5;
        i++;
    }
    printf("sum using while loop is %d.\n",sumw);
    i=1;

    // using do-while loop
    do{
        sumd+=i*5;
        i++;
    }while(i<n);
    printf("sum using do-while loop is %d.\n",sumd);
    return 0;
}