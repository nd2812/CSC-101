#include<stdio.h>
#include<math.h>

int main(){
    int n,i, sumf=0,sumw=0,sumd=0;
    printf("enter a number:");
    scanf("%d", &n);

     // using for loop 
    for(i=0;i<=(n+1)/2;i++){
        sumf+=pow(-1,i)*(2*i+1)*(2*i+1)*(2*i+1);
    }
    printf("sum using for loop is %d.\n",sumf);
    i=0;

    // using while loop
    while(i<=(n+1)/2){
        sumw+=pow(-1,i)*(2*i+1)*(2*i+1)*(2*i+1);
        i++;
    }
    printf("sum using while loop is %d.\n",sumw);
    i=0;

    // using do-while loop
    do{
        sumd+=pow(-1,i)*(2*i+1)*(2*i+1)*(2*i+1);
        i++;
    }while(i<=(n+1)/2);
    printf("sum using do-while loop is %d.\n",sumd);
    return 0;
}