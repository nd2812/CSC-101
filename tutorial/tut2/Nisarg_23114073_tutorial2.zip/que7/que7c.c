#include<stdio.h>
#include<math.h>
int main(){
     int fact=1,n,i,j;
    double sum=1,x;
    printf("Enter the value of x:");
    scanf("%lf",&x);
    printf("Enter the value of n:");
    scanf("%d",&n);
    sum=x;

    // using for loop
    for( i=3;i<=n;i+=2){
        fact=1;
        for( j =1; j<=i;j++){
            fact*=j;
        }
        sum+=(double)(pow(-1,(i-1)/2)*pow(x,i))/fact;
    }
    printf("sum using for loop is %f\n",sum);
    

    // using while loop
    i=3,j=1 ,sum=x,fact=1;
    while(i<=n){
        while(j<=i){
            fact*=j;
            j++;
        }
        sum+=(double)(pow(-1,(i-1)/2)*pow(x,i))/fact;
        i+=2;
    }
    printf("sum using while loop is %f\n",sum);
    sum=x,fact=1;

//     // using do while
i=3,j=1, sum=x,fact=1;
    do{
        do{
            fact*=j;
            j++;
        }while(j<=i);
        sum+=(double)(pow(-1,(i-1)/2)*pow(x,i))/fact;
        i+=2;
    }while(i<=n);
    printf("sum using while loop is %f\n",sum);
    return 0;
}