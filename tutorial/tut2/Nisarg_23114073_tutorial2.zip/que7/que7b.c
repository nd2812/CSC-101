#include <stdio.h>
#include <math.h>

int main()
{
    int fact = 1, n, i, j;
    double sum = 1;
    printf("Enter the value of n:");
    scanf("%d", &n);

    // using for loop
    for (i = 1; i <= n; i++)
    {
        fact = 1;
        for (j = 1; j <= i; j++)
        {
            fact *= j;
        }
        sum += (double)(pow(-1, i) * i) / fact;
    }
    printf("sum using for loop is %f\n", sum);

    // using while loop
    sum = 1, i = 1, j = 1, fact = 1;
    while (i <= n)
    {
        while (j <= i)
        {
            fact *= j;
            j++;
        }
        sum += (double)(pow(-1, i) * i) / fact;
        i++;
    }
    printf("sum using for loop is %f\n", sum);

    // using do-while loop
    sum = 1, i = 1, j = 1, fact = 1;
    do
    {
        do
        {
            fact *= j;
            j++;
        } while (j <= i);
        sum += (double)(pow(-1, i) * i) / fact;
        i++;
    } while (i <= n);
    printf("sum using do-while loop is %f\n", sum);

    return 0;
}