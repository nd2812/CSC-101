#include<stdio.h>

int main(){
    int n,i, sumf=0,sumw=0,sumd=0;
    printf("enter a number:");
    scanf("%d", &n);

     // using for loop 
    for(i=1;i<=n;i++){
        sumf+=i*i;
    }
    printf("sum using for loop is %d.\n",sumf);
    i=1;

    // using while loop
    while(i<=n){
        sumw+=i*i;
        i++;
    }
    printf("sum using while loop is %d.\n",sumw);
    i=1;

    // using do-while loop
    do{
        sumd+=i*i;
        i++;
    }while(i<=n);
    printf("sum using do-while loop is %d.\n",sumd);
    return 0;
}