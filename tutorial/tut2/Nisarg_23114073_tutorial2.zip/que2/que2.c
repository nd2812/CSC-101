#include <stdio.h>
#include <string.h>
int main(){
    char string[100];
    int count;
    printf("Enter the string : ");
    scanf("%s", string);

    printf("Duplicate characters in a given string: \n");

    for (int i = 0; i < strlen(string); i++)
    {    count = 1; 
        for (int j = i + 1; j < strlen(string); j++)
        {
            if (string[i] == string[j])
            {
                count++;
                string[j] = '0';
            }
        }
        if (count > 1 && string[i] != '0'){
            printf("%c\n", string[i]);
    }
    }
    return 0;
}
