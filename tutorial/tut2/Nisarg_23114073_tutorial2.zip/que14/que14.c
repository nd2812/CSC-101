#include<stdio.h>

int main(){
    int n;
    printf("enter a number:");
    scanf("%d", &n);
    int str[n];
    str[0]=1;
    str[1]=2;
    if(n==1){
        printf("Hemachandra series:1.\n");
    }
    else if (n==2){
       printf("Hemachandra series:1,2.\n");
    }
    else if(n>2){
    printf("Hemachandra series:1,2,");
    for(int i=0;i<n-2;i++){
        str[i+2]=str[i]+str[i+1];
        printf("%d,",str[i+2]);
    }
    }
    return 0;
}