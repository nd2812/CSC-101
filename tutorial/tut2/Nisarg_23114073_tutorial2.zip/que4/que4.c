#include<stdio.h>

int main(){
    char a;
    printf("Enter a capital alphabate:");
    scanf("%c", &a);
    int b=a+32;
    char c=b;
    printf("%c has lowercase alphabate is %c\n",a,c);
    return 0;
}