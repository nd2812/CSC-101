#include<stdio.h>
// using while loop 

int main(){
    int a,max,min,i=1;
    printf("Enter a value of n:");
    scanf("%d", &a);
    printf("Enter a number:");
    int arr[a];
    scanf("%d",&arr[0]);
    max=arr[0];
    min=arr[0];
    while(i<a){
        scanf("%d",&arr[i]);
        if(max<arr[i]){
            max=arr[i];
        }
        if(min>arr[i]){
            min=arr[i];
        }
        i++;
    }
    printf("The maximum number is:%d\n",max);
    printf("The minimum number is:%d\n",min);
    return 0;
}