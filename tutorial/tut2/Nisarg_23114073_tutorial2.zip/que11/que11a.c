#include<stdio.h>
// using for loop

int main(){
    int a,max,min;
    printf("Enter a value of n:");
    scanf("%d", &a);
    printf("Enter the 1th element of array:");
    int arr[a];
    scanf("%d",&arr[0]);
    max=arr[0];
    min=arr[0];
    for(int i=1;i<a;i++){
        printf("Enter the  %dth element of array:",i+1);
        scanf("%d",&arr[i]);
        if(max<arr[i]){
            max=arr[i];
        }
        if(min>arr[i]){
            min=arr[i];
        }
    }
    printf("The maximum number is:%d\n",max);
    printf("The minimum number is:%d\n",min);
    return 0;
}