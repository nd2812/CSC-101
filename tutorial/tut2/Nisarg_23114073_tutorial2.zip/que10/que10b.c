#include<stdio.h>
#include<string.h>


int main(){
    char str[100];
    printf("Enter a word or number:");
    scanf("%s",str);
    int l=strlen(str),p=1;
    for( int i=0,j=l-1;i<j;++i,--j){
        switch(str[i]!= str[j]){
            case 1:
            p=0;
        }
    }
    switch(p){
        case 1:
        printf("%s is a palindrome.\n", str);
        break;
        case 0:
        printf("%s is not a palindrome.\n", str);
    }
    return 0;
}