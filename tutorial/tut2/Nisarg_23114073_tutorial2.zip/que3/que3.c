#include <stdio.h>
int revbit(int n)
{
	int a = sizeof(n) * 8;
	int r = 0;
	for (int i = 0; i < a; i++) {
		if ((n & (1 << i)))
			r |= 1 << ((a - 1) - i);
	}
	return r;
}
int main()
{
	int x;
    printf("Enter a number :");
    scanf("%d",&x);
	printf("%u\n", revbit(x));
	getchar();
}
