#include<stdio.h>

int main(){
    int a;
    printf("Enter a year:");
    scanf("%d", &a);
    if(a%4==0){
        if(a%400 == 0){
        printf("%d year is a leap year.\n",a);
        }    
        else if (a%100 == 0){
        printf("%d year is not a leap year.\n",a);
    }
    }
    else{
        printf("%d year is not a leap year.\n",a);
    }
    return 0;
}