#include<stdio.h>

int main(){
    int a, b=0;
    printf("Enter a number:");
    scanf("%d",&a);
    while(a!=1){
        if(a%2==0){
            a=a/2;
        }
        else{
            a=a*3+1;
        }
        b++;
    }
    printf("%d times the operations are performed.\n", b);
    return 0;
}