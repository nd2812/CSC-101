#include<stdio.h>

int main(){
    int a,b,c=0;
    printf("Enter a first number:");
    scanf("%d",&a);
    printf("Enter a second number:");
    scanf("%d",&b);
    if(a>b){
        for(int i=2;i<b;i++){
            if(a%i==0 && b%i==0){
             c=1;   
            }
        }
    }
    else if(a<b){
        for(int i=2;i<a;i++){
            if(a%i==0 && b%i==0){
               c=1;
        }
    }
    }
    if(c==1){
        printf("the numbers are not relatively prime numbers.");
    }
    else{
        printf("the numbers are relatively prime numbers.");
    }
    return 0;
}