#include<stdio.h>

int main(){
    int a,b,c;
    printf("Enter a first number:");
    scanf("%d",&a);
    printf("Enter a second number:");
    scanf("%d",&b);
    printf("write 1 for +\nwrite 2 for -\nwrite 3 for *\nwrite 4 for /\nwrite 5 for (%)");
    scanf("%d",&c);

    if(c==1){
        printf("%d + %d = %d",a,b,a+b);
    }
    else if(c==2){
        printf("%d - %d = %d",a,b,a-b);
    }
    else if(c==3){
        printf("%d * %d = %d",a,b,a*b);
    }
    else if(c==4){
        printf("%d / %d = %d",a,b,a/b);
    }
    else if(c==5){
        printf("%d  (%)  %d = %d",a,b,a%b);
    }
    else{
        printf("enter a valid number.");
    }
    return 0;
}