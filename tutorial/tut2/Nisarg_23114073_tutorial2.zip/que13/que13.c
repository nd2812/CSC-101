#include<stdio.h>

int main(){
    int sum=0;
    for (int i=2;i<100000;i++){
        for(int j=1;j<=i/2;j++){
            if(i%j==0){
                sum+=j;
            }
        }
        if(sum==i){
            printf("%d is perfect number.\n",i);
        }
        sum=0;
    }
    return 0;
}