#include <stdio.h>
#include <string.h>

int count(int m,char n[]){
    int c=0;
    for(int i=0;i<strlen(n);i++){
        if(m==n[i]-48){
            c++;
        }
    }
    return c;
}
int main() {
    char n[20];
    int m;
    printf("Enter a Number:");
    scanf("%s",n);
    printf("Enter a digit that you want to count in number:");
    scanf("%d",&m);
    printf("Given digit %d in number %s has count is %d. \n",m,n,count(m,n));

    return 0;
}
