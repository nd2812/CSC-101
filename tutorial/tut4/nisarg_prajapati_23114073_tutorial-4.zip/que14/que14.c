#include <stdio.h>
#include <string.h>
#include <ctype.h>

void transform(char s[]){
    int l = strlen(s);
    if(l%2==1 && l>4){
        for(int i=0;i<l;i++){
            printf("%c",s[l-1-i]);
        }
        printf("\n");
    }

    else if(l%2==0 && l>=4){
        for(int i=0;i<l/2;i++){
            printf("%c",s[i+(l/2)]);
        }
        for(int i=0;i<l/2;i++){
            printf("%c",s[i]);
        }
        printf("\n");
    }

    else{
        for(int i=0;i<l;i++){
            printf("%c",toupper(s[i]));
        }
        printf("\n");
    }
}
int main(){
    int n;
    printf("Enter number of strings:");
    scanf("%d",&n);

    char a[n][100];
    for(int i=0;i<n;i++){
        printf("Enter string %d:",i+1);
        scanf("%s",a[i]);
    }    

    printf("\n");
    for(int i=0;i<n;i++){
        transform(a[i]);
    }
    return 0;
}