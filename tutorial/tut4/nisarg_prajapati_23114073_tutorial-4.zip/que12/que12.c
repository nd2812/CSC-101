#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>

bool palin(char s[],int l){
    for(int i=0;i<(l/2);i++){
        if(tolower(s[i])!=tolower(s[l-1-i])){
            return false;
        }
    }
    return true;
}

int main(){
    char str[100];
    printf("Enter your string:");
    fgets(str,sizeof(str),stdin);
    int l = strlen(str)-1;
    int c=0;
    for(int i=0;i<l;i++){        
        for(int j=i+1;j<l;j++){
            char s2[l];
            int k;
            for(k=i;k<=j;k++){
                s2[k-i] = str[k];
            }
            s2[k-i] = '\0';
            if(palin(s2,j-i+1)){
                printf("%s : %d - %d\n",s2,i,j);
                c++;
            }
        }
    }
    if(c == 0){
        printf("No palindrome substring found\n");
    }
    return 0;
}