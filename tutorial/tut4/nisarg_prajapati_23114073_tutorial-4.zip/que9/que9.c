#include <stdio.h>
#include <math.h>
#include <stdbool.h>

int delete(float* a,int b,int c){
    for(int i=b;i<c-1;i++){
        *(a+i) = *(a+i+1);
    }
}

bool prime(int n){
    if(n<2){
        return false;
    }
    for(int i=2;i<=sqrt(n);i++){
        if(n%i==0){
            return false;
        }
    }
    return true;
}

int main(){
    float a[] = {1.23, 45.6, 23.2, 45.4, 99.2, 35.4};
    int l = sizeof(a)/sizeof(a[0]);
    printf("Your array is :");
    for(int i=0;i<l;i++){
        printf("%.3f ",a[i]);
    }
    printf("\nNew array is :");
    int in = 0;
    for(int i=1;i<=l;i++){
        if(prime(i)){
            delete(a,i-1-in,l-in);
            in ++;
        }
    }
    for(int i=0;i<l-in;i++){
        printf("%.3f ",a[i]);
    }
    printf("\n");
    return 0;
}