#include <stdio.h>
#include <stdlib.h>
#include <math.h>

void printmat(int n,int li[n][n]){
    printf("\n");
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            printf("%d ",li[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

int det2(int li[2][2]){
    return (li[0][0]*li[1][1] - li[0][1]*li[1][0]);
}

int det3(int li[3][3]){
    int val = 0;
    int r=0,c=0;
    for(int i=0;i<3;i++){
        int m2[2][2];
        for(int j=1;j<3;j++){
            for(int k=0;k<3;k++){
                if(i==k){
                    continue;
                }
                m2[r][c] = li[j][k];
                c++;
            }
            r++;
            c=0;
        }
        r=0;
        val += pow(-1,i)*det2(m2)*li[0][i];
    }
    return val;
}

int main(){
    int coeff[3][3];
    int cons[3][1];

    for(int i=0;i<3;i++){
        printf("Enter a,b,c,d for eqn %d - ",i+1);
        scanf("%d %d %d %d",&coeff[i][0],&coeff[i][1],&coeff[i][2],&cons[i][0]);
    }

    int adj[3][3];
    int r=0,c=0;
    for(int i=0;i<3;i++){
        for(int w=0;w<3;w++){
            int m2[2][2];
            for(int j=0;j<3;j++){
                if(i==j)
                    continue;
                for(int k=0;k<3;k++){
                    if(w==k)
                        continue;
                    m2[r][c] = coeff[j][k];
                    c++;
                }
                r++;
                c=0;
            }
            r=0;
            adj[i][w]= pow(-1,i+w)*det2(m2);
        }
    }

    int mult[3][1];
    for(int i=0;i<3;i++){
            mult[i][0] = 0;
    }
    for(int i=0;i<3;i++){
        for(int j=0;j<1;j++){
            for(int k=0;k<3;k++){
                mult[i][j] += adj[i][k]*cons[k][j];
            }
        }
    }
    
    
    int d = det3(coeff);
    if(d==0){
        printf("No unique solution\n");
        return 0;
    }
    
    printf("Unique solution exists\nThese are:");
    for(int i=0;i<3;i++){
        printf("%.3f ",mult[i][0]/(float)d);
    }
    printf("\n");
    return 0;
}