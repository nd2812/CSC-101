#include<stdio.h>
int a[50];
int c=0;

int octal(int n){
    if(n<8){
        a[c] = n;
        return 0;
    }
    a[c] = n%8;
    c++;
    octal(n/8);
}

int main(){
    int n;
    printf("Enter a decimal Number:");
    scanf("%d",&n);
    octal(n);
    printf("Octal number of %d is ",n);
    for(int i=c;i>=0;i--){
        printf("%d",a[i]);
    }
    printf("\n");
    return 0;
}