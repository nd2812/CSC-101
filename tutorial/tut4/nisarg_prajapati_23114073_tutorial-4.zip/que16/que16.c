#include<stdio.h>
#include <stdlib.h>
#include <math.h>

void printmat(int n,int li[n][n]){
    printf("\n");
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            printf("%d ",li[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

float avg(int n,int math[n][n],int i,int j){
    int sum=0,count=0;
    if(i<n-1){
        sum += math[i+1][j];
        count++;
    }
    if(j<n-1){
        sum += math[i][j+1];
        count++;
    }
    if(i>0){
        sum += math[i-1][j];
        count++;
    }
    if(j>0){
        sum += math[i][j-1];
        count++;
    }
    return (float)sum/count;
}

int main(){
    int n;
    printf("Enter the order of matrix:");
    scanf("%d",&n);
    int a[n][n],b[n][n],c[n][n],d[n][n],e[n][n];
    printf("Enter matrix A:\n");
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            printf("a[%d][%d]=",i+1,j+1);
            scanf("%d",&a[i][j]);
        }
    }
    printf("Enter matrix B:\n");
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            printf("b[%d][%d]=",i+1,j+1);
            scanf("%d",&b[i][j]);
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            c[i][j]=0;
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            for(int k=0;k<n;k++){
                c[i][j]+=a[i][k] * b [k][j];
            }
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            d[i][j]=c[j][i];
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            e[i][j] = ceil(fabs(d[i][j]-avg(n,d,i,j)));
        }
    }
    printmat(n,e);
    return 0;
}