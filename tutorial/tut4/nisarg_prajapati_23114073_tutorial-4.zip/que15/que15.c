#include <stdio.h>

int search(int n,int m,int math[n][m],int i,int j){
    if(math[i][j+1]==1)
        return 1;
    else if(math[i+1][j]==1)
        return 2;
    else
        return 0;
}

int main(){
    int n,m;
    printf("Enter rows and columns:");
    scanf("%d %d",&n,&m);
    int math[n][m];
    
    for(int i=0;i<n;i++){
        printf("Enter row %d:",i+1);
        for(int j=0;j<m;j++){
            scanf("%d",&math[i][j]);
        }
    }

    printf("\n");
    int c=0,b=0;
    if(math[c][b]!=1){
        printf("No path found\n");
        return 0;
    }
    int a[(n-1)+(m-1)];

    while(c!=n-1 || b!=m-1){
        int k = search(n,m,math,c,b);
        if(k==1){
            a[c+b] = k;
            b++;
        }
        else if(k==2){
            a[c+b] = k;
            c++;
        }
        else{
            printf("No path found\n");
            return 0;
        }
    }

    for(int i=0;i<c+b;i++){
        if(a[i]==1){
            printf("R");
        }
        else if (a[i]==2){
            printf("D");
        }
    }
    printf("\n");
    return 0;
}