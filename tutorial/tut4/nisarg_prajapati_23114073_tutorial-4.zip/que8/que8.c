#include <stdio.h>

float mean(float a[],int *l){
    float s = 0;
    for(int i=0;i<*l;i++){
        printf("%.2f ",a[i]);
        s += a[i];
        for(int j=0;j<*l;j++){
            if(a[i]>a[j]){
                int t = a[i];
                a[i] = a[j];
                a[j] = t;
            }
        }
    }
    float b=*l;
    return s/b;
}

float median(float a[],int *l){
    float median;
    if(*l%2==0){
        median = ((a[*l/2]) + (a[(*l/2)-1]))/2.0 ;
    }
    else{
        median = (a[(*l-1)/2]);
    }
    return median;
}

int main(){
    float a[] = {8,45,20,4,13};
    int l = sizeof(a)/sizeof(a[0]);
    printf("Your array is:");
    
    printf("\nMean: %f\n",mean(a,&l));
    printf("Median: %f\n",median(a,&l));
    return 0;
}