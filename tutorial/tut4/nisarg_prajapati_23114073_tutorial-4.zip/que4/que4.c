#include<stdio.h>

int sum_digit (int n, int k){
    int sum=0;
    while(k>=0){
        int digit = n % 10;
        sum += digit;
        n/=10;
        k--;
    }
    return sum;
}

int main(){
    int n;
    printf("Enter a number:");
    scanf("%d",&n);
    printf("sum_digit(%d,0)=%d\n",n,sum_digit(n,0));
    printf("sum_digit(%d,2)=%d\n",n,sum_digit(n,2));
    return 0;
}