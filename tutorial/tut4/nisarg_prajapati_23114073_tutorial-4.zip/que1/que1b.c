#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(){
    char st[100];
    printf("Enter your string:");
    fgets(st,sizeof(st),stdin);
    char a[52] = {'a','A','b','B','c','C','d','D','E','e','f','F','g','G','h','H','i','I','j','J','k','K','l','L','m','M','n','N','o','O','p','P','q','Q','r','R','s','S','t','T','u','U','v','V','w','W','x','X','y','Y','z','Z'};
    int n[52] = {2,2,22,22,222,222,3,3,33,33,333,333,4,4,44,44,444,444,5,5,55,55,555,555,6,6,66,66,666,666,7,7,77,77,777,777,7777,7777,8,8,88,88,888,888,9,9,99,99,999,999};
    int l = strlen(st)-1;

    for(int i=0;i<l;i++){
        int b,k=0;
        char c = tolower(st[i]);
        for(int j=0;j<52;j++){
            if(c==a[j]){
                b = n[j];
                k = 1;
            }
        }
        if(k==1){
            printf("%d",b);
        }
    }
    printf("\n");
    return 0;
}