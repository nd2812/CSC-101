#include <stdio.h>
#include <string.h>

int main(){
    char st[100];
    printf("Enter your string:");
    fgets(st,sizeof(st),stdin);
    int l = strlen(st)-1;
    for(int i=0;i<l;i++){
        int k;
        if(st[i]=='A'||st[i]=='a'){
            k=2;
        }
        else if(st[i]=='B'||st[i]=='b'){
            k=22;
        }
        else if(st[i]=='C'||st[i]=='c'){
            k=222;
        }
        else if(st[i]=='D'||st[i]=='d'){
            k=3;
        }
        else if(st[i]=='E'||st[i]=='e'){
            k=33;
        }
        else if(st[i]=='F'||st[i]=='f'){
            k=333;
        }
        else if(st[i]=='G'||st[i]=='g'){
            k=4;
        }
        else if(st[i]=='H'||st[i]=='h'){
            k=44;
        }
        else if(st[i]=='I'||st[i]=='i'){
            k=444;
        }
        else if(st[i]=='J'||st[i]=='j'){
            k=5;
        }
        else if(st[i]=='K'||st[i]=='k'){
            k=55;
        }
        else if(st[i]=='L'||st[i]=='l'){
            k=555;
        }
        else if(st[i]=='M'||st[i]=='m'){
            k=6;
        }
        else if(st[i]=='N'||st[i]=='n'){
            k=66;
        }
        else if(st[i]=='O'||st[i]=='o'){
            k=666;
        }
        else if(st[i]=='P'||st[i]=='p'){
            k=7;
        }
        else if(st[i]=='Q'||st[i]=='q'){
            k=77;
        }
        else if(st[i]=='R'||st[i]=='r'){
            k=777;
        }
        else if(st[i]=='S'||st[i]=='s'){
            k=7777;
        }
        else if(st[i]=='T'||st[i]=='t'){
            k=8;
        }
        else if(st[i]=='U'||st[i]=='u'){
            k=88;
        }
        else if(st[i]=='V'||st[i]=='v'){
            k=888;
        }
        else if(st[i]=='W'||st[i]=='w'){
            k=9;
        }
        else if(st[i]=='X'||st[i]=='x'){
            k=99;
        }
        else if(st[i]=='Y'||st[i]=='y'){
            k=999;
        }
        else if(st[i]=='Z'||st[i]=='z'){
            k=9999;
        }
        else {
            printf("%c",st[i]);
        }
        printf("%d",k);
    }
    printf("\n");
    return 0;
}