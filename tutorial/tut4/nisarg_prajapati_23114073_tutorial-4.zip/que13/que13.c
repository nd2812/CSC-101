#include<stdio.h>

int main(){
    int m,n;
    printf("Enter a row:");
    scanf("%d",&m);
    printf("Enter a column:");
    scanf("%d",&n);
    int a[m][n];
    for(int i=0;i<m;i++){
        for(int j=0;j<n;j++){
            printf("a[%d][%d]=",i,j);
            scanf("%d",&a[i][j]);
        }
    }
    for(int i=1;i<m;i++){
        for(int j=1;j<n;j++){
            if(a[i][j]>a[i-1][j] &&a[i][j]>a[i+1][j] &&a[i][j]>a[i][j-1] &&a[i][j]>a[i][j+1] ){
                printf("(%d,%d)",i,j);
            }
        }
    }
    printf("\n");
    return 0;
}