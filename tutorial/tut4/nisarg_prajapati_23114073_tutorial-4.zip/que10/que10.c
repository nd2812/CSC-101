#include <stdio.h>
#include <stdlib.h>

void insert(int* a,int b,int c,int d){
    for(int j=d-1;j>c;j--){
        *(a+j) = *(a+j-1);
    }
    *(a+c) = b;
}

void printarr(int* a,int b){
    for(int i=0;i<b;i++){
        printf("%d ",a[i]);
    }
}
int main(){
    int t,n,i;
    printf("Enter number of elements:");
    scanf("%d",&n);
    int* a;
    a = (int*) malloc(n*sizeof(int));
    for(int i=0;i<n;i++){
        printf("Enter element number %d:",i+1);
        scanf("%d",&a[i]);
    }
    printf("\nYour array is:");
    printarr(a,n);
    printf("\n");
    printf("Enter new element to add:");
    scanf("%d",&t);
    printf("Enter the index to insert:");
    scanf("%d",&i);
    n++;
    a = (int*) realloc(a,n*sizeof(int));
    insert(a,t,i,n);

    printf("\nNew array is:");
    printarr(a,n);
    printf("\n");
    return 0;
}