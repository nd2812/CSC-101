#include <stdio.h>
#include <string.h>

int pig(char st[],int l){
    char v[] = {'a','e','i','o','u','A','E','I','O','U'};
    char p[l+3];
    for(int i=0;i<10;i++){
        if(st[0]==v[i]){
            for(int j=0;j<l;j++){
                p[j] = st[j];
            }
            p[l] = 'w';
            p[l+1] = 'a';
            p[l+2] = 'y';
            p[l+3] = '\0';
            printf("%s ",p);
            return 0;
        }
    }

    for(int i=0;i<l;i++){
        for(int j=0;j<10;j++){
            if(st[i]==v[j]){
                int k;
                for(k=0;k<l-i;k++){
                    p[k] = st[k+i];
                }
                for(int t=k;t<l;t++){
                    p[t] = st[t-k];
                }
                p[l] = 'a';
                p[l+1] = 'y';
                p[l+2] = '\0';
                printf("%s ",p);
                return 0;
            }
        }
    }

    for(int i=0;i<l;i++){
        p[i] = st[i];
    }
    p[l] = 'a';
    p[l+1] = 'y';
    p[l+2] = '\0';
    printf("%s ",p);
    return 0;
}

int main(){
    char st[100];
    printf("Enter your string:");
    fgets(st,sizeof(st),stdin);
    int l = strlen(st)-1;
    int a=0,i;
    
    for(i=0;i<l;i++){
        if(st[i]==' '){
            char sub[i-a];
            for(int j=0;j<i-a;j++){
                sub[j] = st[j+a];
            }
            pig(sub,i-a);
            a = i+1;
        }
    }

    char sub[i+1-a];
    for(int j=0;j<i-a;j++){
        sub[j] = st[j+a];
    }
    pig(sub,i-a);
    a = i+1;
    printf("\n");
    return 0;
}