#include <stdio.h>

int f(int i){
    if(i==0){
        return 0;
    }
    if(i%2==0){
        return f(i/2)+f(i/2);
    }
    else{
        return f(i-1) +1;
    }
}

int main() {
    printf("F(11):%d\n",f(11));
    return 0;
}